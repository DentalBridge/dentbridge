export interface User {
  id: number;
  email: string;
  fullName: string;
  role: string;
}

export interface AuthResponse {
  token: string;
  type: string;
  id: number;
  email: string;
  fullName: string;
  role: string;
}

export interface Patient {
  id: number;
  name: string;
  gender: string;
  email?: string;
  phone?: string;
  address?: string;
  dateOfBirth?: string;
  medicalHistory?: string;
  allergies?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Appointment {
  id: number;
  patientId: number;
  patientName: string;
  appointmentDateTime: string;
  durationMinutes: number;
  status: string;
  treatmentType?: string;
  notes?: string;
  googleCalendarEventId?: string;
  createdBy: number;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: number;
  patientId: number;
  patientName: string;
  appointmentId?: number;
  amount: number;
  paymentDate: string;
  paymentMethod: string;
  status: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InventoryItem {
  id: number;
  itemName: string;
  category?: string;
  description?: string;
  quantity: number;
  unitPrice?: number;
  unitOfMeasure?: string;
  reorderLevel?: number;
  supplier?: string;
  isLowStock: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Treatment {
  id: number;
  patientId: number;
  patientName: string;
  appointmentId?: number;
  treatmentName: string;
  description?: string;
  cost?: number;
  treatmentDate: string;
  performedBy: number;
  performedByName: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentStats {
  totalPaid: number;
  totalPending: number;
  totalPayments: number;
}

export interface DashboardStats {
  totalPatients: number;
  appointmentsToday: number;
  pendingPayments: number;
  lowStockItems: number;
}

export interface ApiError {
  timestamp: string;
  status: number;
  error: string;
  message: string;
  path: string;
  validationErrors?: Record<string, string>;
}

const Logo = ({ className = "" }: { className?: string }) => {
  return (
    <div className={`flex flex-col items-center ${className}`}>
      {/* Teeth Icon */}
      <div className="mb-4">
        <svg
          width="80"
          height="80"
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-primary-600"
        >
          {/* Tooth shape - simplified dental icon */}
          <path
            d="M50 10C35 10 25 20 25 35C25 45 22 55 22 65C22 75 27 85 35 85C40 85 42 80 45 75C47 71 48 70 50 70C52 70 53 71 55 75C58 80 60 85 65 85C73 85 78 75 78 65C78 55 75 45 75 35C75 20 65 10 50 10Z"
            fill="currentColor"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Sparkle/shine effect */}
          <circle cx="40" cy="30" r="3" fill="white" opacity="0.8" />
          <circle cx="48" cy="25" r="2" fill="white" opacity="0.6" />
        </svg>
      </div>

      {/* Brand Name */}
      <h1 className="text-4xl font-bold text-gray-900 mb-2">
        DentBridge
      </h1>

      {/* Tagline */}
      <p className="text-sm text-gray-600 font-medium tracking-wide uppercase">
        Dental Healthcare
      </p>
    </div>
  );
};

export default Logo;

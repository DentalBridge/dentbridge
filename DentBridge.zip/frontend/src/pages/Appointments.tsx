import Layout from '../components/Layout';
import { AppointmentCalendar } from '../components/DentalIllustration';

const Appointments = () => {
  return (
    <Layout>
      <div>
        <div className="sm:flex sm:items-center sm:justify-between mb-6">
          <div>
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Appointments
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Schedule and manage patient appointments
            </p>
          </div>
          <button className="mt-4 sm:mt-0 btn btn-primary">
            Schedule Appointment
          </button>
        </div>

        <div className="bg-white shadow rounded-lg p-8">
          <div className="text-center">
            <AppointmentCalendar className="w-48 h-48 mx-auto mb-6" />
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Appointment Calendar</h4>
            <p className="text-gray-600 mb-4">
              Advanced appointment scheduling with calendar view coming soon.
            </p>
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-left max-w-2xl mx-auto">
              <div className="bg-primary-50 p-4 rounded-lg">
                <h5 className="font-medium text-primary-900 mb-2">📅 Calendar View</h5>
                <p className="text-sm text-gray-600">Interactive calendar for scheduling</p>
              </div>
              <div className="bg-primary-50 p-4 rounded-lg">
                <h5 className="font-medium text-primary-900 mb-2">🔗 Google Sync</h5>
                <p className="text-sm text-gray-600">Automatic Google Calendar integration</p>
              </div>
              <div className="bg-primary-50 p-4 rounded-lg">
                <h5 className="font-medium text-primary-900 mb-2">🔔 Reminders</h5>
                <p className="text-sm text-gray-600">Automated email and SMS reminders</p>
              </div>
              <div className="bg-primary-50 p-4 rounded-lg">
                <h5 className="font-medium text-primary-900 mb-2">📊 Status Tracking</h5>
                <p className="text-sm text-gray-600">Track scheduled, completed, cancelled</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Appointments;

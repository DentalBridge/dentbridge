import Layout from '../components/Layout';
import { ToothHealthy } from '../components/DentalIllustration';

const Treatments = () => {
  return (
    <Layout>
      <div>
        <div className="sm:flex sm:items-center sm:justify-between mb-6">
          <div>
            <h3 className="text-lg font-medium leading-6 text-gray-900">
              Treatments
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Manage patient treatment records and history
            </p>
          </div>
          <button className="mt-4 sm:mt-0 btn btn-primary">
            Add Treatment
          </button>
        </div>

        <div className="bg-white shadow rounded-lg p-8">
          <div className="text-center">
            <ToothHealthy className="w-40 h-40 mx-auto mb-6" />
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Treatment Management</h4>
            <p className="text-gray-600 mb-6">
              Comprehensive treatment tracking powered by DentBridge
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left max-w-2xl mx-auto">
              <div className="bg-green-50 p-4 rounded-lg">
                <h5 className="font-medium text-green-900 mb-2">📝 Treatment History</h5>
                <p className="text-sm text-gray-600">Complete treatment records for each patient</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h5 className="font-medium text-green-900 mb-2">💰 Cost Tracking</h5>
                <p className="text-sm text-gray-600">Track treatment costs and billing</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h5 className="font-medium text-green-900 mb-2">🔗 Appointment Link</h5>
                <p className="text-sm text-gray-600">Link treatments to appointments</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h5 className="font-medium text-green-900 mb-2">📊 Analytics</h5>
                <p className="text-sm text-gray-600">Generate treatment reports and insights</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Treatments;
